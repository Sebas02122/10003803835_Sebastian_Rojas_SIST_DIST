package com.mycompany.parcial.Controller;

import com.mycompany.parcial.Modelo.Credito;
import com.mycompany.parcial.Service.ServiceCredito;
import com.mycompany.parcial.View.frmCredito;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ControllerCredito implements ActionListener {

    private final Credito credito;

    private final ServiceCredito serviceCredito;

    private final frmCredito vista;

    public ControllerCredito(Credito credito, ServiceCredito serviceCredito, frmCredito vista) {
        this.credito = credito;
        this.serviceCredito = serviceCredito;
        this.vista = vista;
        this.vista.btnGuardar.addActionListener(this);
        this.vista.btnModificar.addActionListener(this);
        this.vista.btnEliminar.addActionListener(this);
        this.vista.btnLimpiar.addActionListener(this);
        this.vista.btnBuscar.addActionListener(this);
    }

    public void iniciar() {
        vista.setTitle("Credito");
        vista.setLocationRelativeTo(null);
        vista.txtId.setVisible(false);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == vista.btnGuardar) {
            credito.setId(vista.txtId.getText());
            credito.setEstado(vista.txtEstado.getText());
            credito.setFecha(vista.txtFecha.getText());
            credito.setValor(Integer.parseInt(vista.txtValor.getText()));

            if (serviceCredito.registrar(credito)) {
                JOptionPane.showMessageDialog(null, "Registro Guardado");
                limpiar();
            } else {
                JOptionPane.showMessageDialog(null, "Error al Guardar");
                limpiar();
            }
        }

        if (e.getSource() == vista.btnModificar) {
            credito.setId(vista.txtId.getText());
            credito.setEstado(vista.txtEstado.getText());
            credito.setFecha(vista.txtFecha.getText());
            credito.setValor(Integer.parseInt(vista.txtValor.getText()));

            if (serviceCredito.modificar(credito)) {
                JOptionPane.showMessageDialog(null, "Registro Modificado");
                limpiar();
            } else {
                JOptionPane.showMessageDialog(null, "Error al Modificar");
                limpiar();
            }
        }

        if (e.getSource() == vista.btnEliminar) {
            credito.setId(vista.txtId.getText());

            if (serviceCredito.eliminar(credito)) {
                JOptionPane.showMessageDialog(null, "Registro Eliminado");
                limpiar();
            } else {
                JOptionPane.showMessageDialog(null, "Error al Eliminar");
                limpiar();
            }
        }

        if (e.getSource() == vista.btnBuscar) {
            credito.setId(vista.txtId.getText());

            if (serviceCredito.buscar(credito)) {
                vista.txtId.setText(String.valueOf(credito.getId()));
                vista.txtEstado.setText(credito.getEstado());
                vista.txtFecha.setText(credito.getFecha());
                vista.txtValor.setText(String.valueOf(credito.getValor()));

            } else {
                JOptionPane.showMessageDialog(null, "No se encontro registro");
                limpiar();
            }
        }

        if (e.getSource() == vista.btnLimpiar) {
            limpiar();
        }
    }

    public void limpiar() {
        vista.txtId.setText(null);
        vista.txtEstado.setText(null);
        vista.txtFecha.setText(null);
        vista.txtValor.setText(null);
    }
}
