package com.mycompany.parcial.Service;

import com.mycompany.parcial.Conexion.Conexion;
import com.mycompany.parcial.Modelo.Credito;
import com.mycompany.parcial.Modelo.Personas;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ServicePersona extends Conexion {

    public boolean registrar(Personas personas) {
        PreparedStatement ps = null;
        Connection con = getConexion();

        String sql = "INSERT INTO persona (tipoDocuemto, numDocumento, nomCompleto , direccion) VALUES(?,?,?,?)";

        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, personas.getTipoDocumento());
            ps.setString(2, personas.getNumDocumento());
            ps.setString(3, personas.getNombreCompleto());
            ps.setString(4, personas.getDireccion());
            ps.execute();
            return true;
        } catch (SQLException e) {
            System.err.println(e);
            return false;
        } finally {
            try {
                con.close();
            } catch (SQLException e) {
                System.err.println(e);
            }
        }
    }

    public boolean modificar(Personas personas) {
        PreparedStatement ps = null;
        Connection con = getConexion();

        String sql = "UPDATE persona SET tipoDocuemto=?, numDocumento=?, nomCompleto=?, direccion=? WHERE numDocumento=? ";

        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, personas.getTipoDocumento());
            ps.setString(2, personas.getNumDocumento());
            ps.setString(3, personas.getNombreCompleto());
            ps.setString(4, personas.getDireccion());
            ps.execute();
            return true;
        } catch (SQLException e) {
            System.err.println(e);
            return false;
        } finally {
            try {
                con.close();
            } catch (SQLException e) {
                System.err.println(e);
            }
        }
    }

    public boolean eliminar(Personas personas) {
        PreparedStatement ps = null;
        Connection con = getConexion();

        String sql = "DELETE FROM persona WHERE numDocumento=? ";

        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, personas.getNumDocumento());
            ps.execute();
            return true;
        } catch (SQLException e) {
            System.err.println(e);
            return false;
        } finally {
            try {
                con.close();
            } catch (SQLException e) {
                System.err.println(e);
            }
        }
    }

    public boolean buscar(Personas personas) {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection con = getConexion();

        String sql = "SELECT * FROM persona WHERE id=? ";

        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, personas.getNumDocumento());
            rs = ps.executeQuery();

            if (rs.next()) {
                personas.setTipoDocumento(rs.getString("tipoDocumento"));
                personas.setNumDocumento(rs.getString("numDocumento"));
                personas.setNombreCompleto(rs.getString("nombreCompleto"));
                personas.setDireccion(rs.getString("direccion"));
                return true;
            }
            return false;
        } catch (SQLException e) {
            System.err.println(e);
            return false;
        } finally {
            try {
                con.close();
            } catch (SQLException e) {
                System.err.println(e);
            }
        }
    }
}
