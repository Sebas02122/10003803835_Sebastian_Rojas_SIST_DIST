package com.mycompany.parcial.Service;

import com.mycompany.parcial.Conexion.Conexion;
import com.mycompany.parcial.Modelo.Credito;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ServiceCredito extends Conexion {

    public boolean registrar(Credito credito) {
        PreparedStatement ps = null;
        Connection con = getConexion();

        String sql = "INSERT INTO credito (id, estado, fecha , valor) VALUES(?,?,?,?)";

        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, credito.getId());
            ps.setString(2, credito.getEstado());
            ps.setInt(3, credito.getValor());
            ps.setString(4, credito.getFecha());
            ps.execute();
            return true;
        } catch (SQLException e) {
            System.err.println(e);
            return false;
        } finally {
            try {
                con.close();
            } catch (SQLException e) {
                System.err.println(e);
            }
        }
    }

    public boolean modificar(Credito credito) {
        PreparedStatement ps = null;
        Connection con = getConexion();

        String sql = "UPDATE credito SET id=?, esatdo=?, fecha=?, valor=? WHERE id=? ";

        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, credito.getId());
            ps.setString(2, credito.getEstado());
            ps.setInt(3, credito.getValor());
            ps.setString(4, credito.getFecha());
            ps.execute();
            return true;
        } catch (SQLException e) {
            System.err.println(e);
            return false;
        } finally {
            try {
                con.close();
            } catch (SQLException e) {
                System.err.println(e);
            }
        }
    }

    public boolean eliminar(Credito credito) {
        PreparedStatement ps = null;
        Connection con = getConexion();

        String sql = "DELETE FROM credito WHERE id=? ";

        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, credito.getId());
            ps.execute();
            return true;
        } catch (SQLException e) {
            System.err.println(e);
            return false;
        } finally {
            try {
                con.close();
            } catch (SQLException e) {
                System.err.println(e);
            }
        }
    }

    public boolean buscar(Credito credito) {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection con = getConexion();

        String sql = "SELECT * FROM credito WHERE id=? ";

        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, credito.getId());
            rs = ps.executeQuery();

            if (rs.next()) {
                credito.setId(rs.getString("id"));
                credito.setEstado(rs.getString("estado"));
                credito.setFecha(rs.getString("fecha"));
                credito.setValor(Integer.parseInt(rs.getString("valor")));
                return true;
            }
            return false;
        } catch (SQLException e) {
            System.err.println(e);
            return false;
        } finally {
            try {
                con.close();
            } catch (SQLException e) {
                System.err.println(e);
            }
        }
    }


}
