package com.mycompany.parcial.Controller;

import com.mycompany.parcial.Modelo.Personas;
import com.mycompany.parcial.Service.ServicePersona;
import com.mycompany.parcial.View.frmPersona;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ControllerPersona implements ActionListener {

    private final Personas personas;

    private final ServicePersona servicePersona;

    private final frmPersona vista;

    public ControllerPersona(Personas personas, ServicePersona servicePersona, frmPersona vista) {
        this.personas = personas;
        this.servicePersona = servicePersona;
        this.vista = vista;
        this.vista.btnGuardar.addActionListener(this);
        this.vista.btnModificar.addActionListener(this);
        this.vista.btnEliminar.addActionListener(this);
        this.vista.btnLimpiar.addActionListener(this);
        this.vista.btnBuscar.addActionListener(this);
    }

    public void iniciar() {
        vista.setTitle("Credito");
        vista.setLocationRelativeTo(null);
        vista.txtNum.setVisible(false);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == vista.btnGuardar) {
            personas.setTipoDocumento(vista.txtTipo.getText());
            personas.setNumDocumento(vista.txtNum.getText());
            personas.setNombreCompleto(vista.txtNombre.getText());
            personas.setDireccion(vista.txtdireccion.getText());

            if (servicePersona.registrar(personas)) {
                JOptionPane.showMessageDialog(null, "Registro Guardado");
                limpiar();
            } else {
                JOptionPane.showMessageDialog(null, "Error al Guardar");
                limpiar();
            }
        }

        if (e.getSource() == vista.btnModificar) {
            personas.setTipoDocumento(vista.txtTipo.getText());
            personas.setNumDocumento(vista.txtNum.getText());
            personas.setNombreCompleto(vista.txtNombre.getText());
            personas.setDireccion(vista.txtdireccion.getText());

            if (servicePersona.modificar(personas)) {
                JOptionPane.showMessageDialog(null, "Registro Modificado");
                limpiar();
            } else {
                JOptionPane.showMessageDialog(null, "Error al Modificar");
                limpiar();
            }
        }

        if (e.getSource() == vista.btnEliminar) {
            personas.setNumDocumento(vista.txtNum.getText());

            if (servicePersona.eliminar(personas)) {
                JOptionPane.showMessageDialog(null, "Registro Eliminado");
                limpiar();
            } else {
                JOptionPane.showMessageDialog(null, "Error al Eliminar");
                limpiar();
            }
        }

        if (e.getSource() == vista.btnBuscar) {
            personas.setNumDocumento(vista.txtNum.getText());

            if (servicePersona.buscar(personas)) {
                vista.txtTipo.setText(personas.getTipoDocumento());
                vista.txtNum.setText(personas.getNumDocumento());
                vista.txtNombre.setText(personas.getNombreCompleto());
                vista.txtdireccion.setText(personas.getDireccion());

            } else {
                JOptionPane.showMessageDialog(null, "No se encontro registro");
                limpiar();
            }
        }

        if (e.getSource() == vista.btnLimpiar) {
            limpiar();
        }

    }

    public void limpiar() {
        vista.txtTipo.setText(null);
        vista.txtNum.setText(null);
        vista.txtNombre.setText(null);
        vista.txtdireccion.setText(null);
    }
}
