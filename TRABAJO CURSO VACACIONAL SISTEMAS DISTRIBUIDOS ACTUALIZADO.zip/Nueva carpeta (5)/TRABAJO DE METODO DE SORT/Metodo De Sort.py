numeros = [1000,10000,1000000,100000000]
letras  = ["b","a","c","e","f","d","i","h","k","j","m","l","ñ","n","p","o","r","q","s","u","t","v","w","y","x","z"]

print(f"Lista numeros: {numeros}")

numeros.sort()
print(f"\nLista numeros: {numeros}")
      
numeros.sort(reverse =True)
print(f"\nLista numeros: {numeros}")

# Lista letras

print(f"\nLista letras:(letras)")

letras.sort()
print(f"\nLista letras:{letras}")

letras.sort()
print(f"\nLista letras:{letras}")
letras.sort(reserse = True)
print(f"\nLista letras:{letras}")