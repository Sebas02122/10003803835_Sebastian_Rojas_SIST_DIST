package com.Corhuila.Corte2.Sebastian.Rojas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Corte2SebastianRojasApplicationTests {

	@Test
	void contextLoads() {
	}

}
