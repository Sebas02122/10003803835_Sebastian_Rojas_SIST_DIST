package com.Corhuila.Corte2.Sebastian.Rojas.Service;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.Corhuila.Corte2.Sebastian.Rojas.Entity.Estudiante;
import com.Corhuila.Corte2.Sebastian.Rojas.IRepository.IEstudianteRepository;

@Service
public class EstudianteService implements IEstudianteService {

	@Autowired
	private IEstudianteRepository repository;
	
	@Override
	public List<Estudiante> all() {
		return repository.findAll();
	}

	@Override
	public Optional<Estudiante> findById(Long id) {
		return repository.findById(id);
	}

	@Override
	public Estudiante save(Estudiante Estudiante) {
		
		Estudiante.setFechaCreacion(LocalDateTime.now());		
		return repository.save(Estudiante);
	}

	@Override
	public void update(Estudiante Estudiante, Long id) {
		//validar si existe.            
        Optional<Estudiante> op = repository.findById(id);		
        
        if(op.isEmpty()){
            System.out.println("Dato no encontrado");
        }else {
        	 //Crear nuevo objeto que va a contener los datos que se van actualizar
            Estudiante EstudianteUpdate = op.get();
            EstudianteUpdate.setTipoDocumento(Estudiante.getTipoDocumento());
            EstudianteUpdate.setDocumento(Estudiante.getDocumento());
            EstudianteUpdate.setNombre(Estudiante.getNombre());
            EstudianteUpdate.setApellido(Estudiante.getApellido());
            EstudianteUpdate.setCorreo(Estudiante.getCorreo());
            EstudianteUpdate.setDireccion(Estudiante.getDireccion());
            EstudianteUpdate.setEstado(Estudiante.getEstado());
            EstudianteUpdate.setFechaModificacion(LocalDateTime.now());
            
            //Actualizar el objeto
            repository.save(EstudianteUpdate);
        }
        
        
	}

	@Override
	public void deletePhysical(Long id) {
		repository.deleteById(id);	
	}

	@Override
	public void deleteLogical(Long id) {
		//validar si existe.            
        Optional<Estudiante> op = repository.findById(id);		
        
        if(op.isEmpty()){
            System.out.println("Dato no encontrado");
        }else {
        	 //Crear nuevo objeto que va a contener los datos que se van actualizar
            Estudiante EstudianteUpdate = op.get();
            EstudianteUpdate.setFechaEliminacion(LocalDateTime.now());
            
            //Actualizar el objeto
            repository.save(EstudianteUpdate);
        }		
	}	
}
