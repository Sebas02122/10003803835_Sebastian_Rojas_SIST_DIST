package com.Corhuila.Corte2.Sebastian.Rojas.IService;
import java.util.List;
import java.util.Optional;




import com.Corhuila.Corte2.Sebastian.Rojas.Entity.Estudiante;
public class IEstudianteService {
	//Obtener todo
		public List<Estudiante> all();
		
		//Obtener por ID
		public Optional<Estudiante> findById(Long id);
	 	
		//Crear
		public Estudiante save(Estudiante Estudiante);
		
		//Modificar
		public void update(Estudiante Estudiante, Long id);
		
		//Eliminar Físico
		public void deletePhysical(Long id);
		
		//Eliminar lógico
		public void deleteLogical(Long id);
}
