package com.Corhuila.Corte2.Sebastian.Rojas.Repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.Corhuila.Corte2.Sebastian.Rojas.Entity.Rol;

@Repository
public interface IRolRepository extends JpaRepository<Rol, Long>{

}

