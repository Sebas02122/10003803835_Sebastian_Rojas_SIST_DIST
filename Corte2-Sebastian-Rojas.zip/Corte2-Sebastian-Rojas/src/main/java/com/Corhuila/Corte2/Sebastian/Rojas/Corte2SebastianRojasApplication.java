package com.Corhuila.Corte2.Sebastian.Rojas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Corte2SebastianRojasApplication {

	public static void main(String[] args) {
		SpringApplication.run(Corte2SebastianRojasApplication.class, args);
	}

}
