package Model;

import Conexion.Conn;
import Interface.CRUD;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.SQLException;

/**
 *
 * @author ariel
 */
public class GrupoM implements CRUD {

    private Conn conn;
    private int numeroGrupo;
    
     public GrupoM() {
        this.conn = new Conn(); // Asegúrate de inicializar conn
    }

    public Conn getConn() {
        return conn;
    }

    public void setConn(Conn conn) {
        this.conn = conn;
    }

    public int getNumeroGrupo() {
        return numeroGrupo;
    }

    public void setNumeroGrupo(int numeroGrupo) {
        this.numeroGrupo = numeroGrupo;
    }

    @Override
    public void Agregar() {
        Connection con = null;
        Statement stmt = null;

        try {
            con = conn.getConexion();
            stmt = con.createStatement();
            String sql = "INSERT INTO grupo (numero_grupo) VALUES (" + this.getNumeroGrupo() + ")";

            // Ejecuta la consulta de inserción
            stmt.executeUpdate(sql);

            System.out.println("SE HIZO LA CONSULTA Y SE AÑADIÓ.");
        } catch (SQLException e) {
            System.out.println("Error al agregar el grupo: " + e.getMessage());
        } finally {
            // Cierra el Statement y la conexión en el bloque finally
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException e) {
                }
            }
            if (con != null) {
                conn.cerrarConexion(con);
            }
        }
    }

    @Override
    public void Modificar() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void Eliminar() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public Object Consultar() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public Object ConsultarId() {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}
