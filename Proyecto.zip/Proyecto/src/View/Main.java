/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package View;

import Conexion.Conn;

import javax.swing.*;


/**
 *
 * @author ariel
 */
public class Main {
    public static void main(String[] args) {
        Conn conn = new Conn();
        conn.getConexion();
        System.out.println("Conexión exitosa a la base de datos.");
        
        
         SwingUtilities.invokeLater(() -> {
            GrupoV grupoV = new GrupoV();
            grupoV.setVisible(true);
        });
         
    }
}
